cd /sdcard/Download
cp -r data/ /Android/data/com.leohao.android.alistlite/files/data/